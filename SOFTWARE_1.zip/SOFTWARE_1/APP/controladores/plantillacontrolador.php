<?php

class ControladorPlantilla{
    public function ctrPlantilla(){

        include "APP/vistas/plantilla.php";
    }

}