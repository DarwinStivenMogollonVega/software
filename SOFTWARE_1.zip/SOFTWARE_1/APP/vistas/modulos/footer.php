<footer class="main-footer" style="background-color: #9E47DE;">
    <strong>Copyright &copy; 25/03/2025 <a href="#">Aurisplay</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.2.0
    </div>
  </footer>
  